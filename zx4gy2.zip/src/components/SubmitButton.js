export default function SubHeading() {
  return (
    <div className="App">
      <button>submit </button>
      
    
    </div>
  );
}