export default function Heading() {
  return (
    <div className="heading">
      <h1>this is heading</h1>
    </div>
  );
}
