export default function SubHeading() {
  return (
    <div className="App">
      <h2> this is sub SubHeading</h2>
    </div>
  );
}
