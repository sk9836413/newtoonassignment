export default function InputQuery() {
  return (
    <div className="App">
      <input placeholder="input"></input>
    </div>
  );
}
